<?php

	session_start();
	include"connection.php";
	if(isset($_POST['btnok']))
	{
		$un=$_POST['untxt'];
		$pw=$_POST['pwtxt'];
		
		$q="SELECT * from admin_login where username='$un' AND Password='$pw'";
		$c=mysqli_query($con,$q);
		$r=mysqli_num_rows($c);
		if($r>=1)
		{
			$_SESSION['admin']=$un;
			?>
			<script>
				alert("Successfully Login");
				window.location="index.php";
			</script>
			<?php
		}
		else
		{
			?>
			<script>
				alert("Invalid Username and Password...");
				window.location="adminlogin.php";
			</script>
			<?php
		}
	}
?>
<!DOCTYPE HTML>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Novus Admin Panel Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- font CSS -->
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons -->
 <!-- js-->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<!--webfonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--//webfonts--> 
<!--animate-->
<link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
<script src="js/wow.min.js"></script>
	<script>
		 new WOW().init();
	</script>
<!--//end-animate-->
<!-- Metis Menu -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
</head> 


<div id="page-wrapper">
			<div class="main-page login-page ">
				<h3 class="title1">Login Page</h3>
				<div class="widget-shadow">
					
					<div class="login-body">
						<form action="#" method="post">
							<input type="text" class="user" name="untxt" placeholder="Enter your email" required="">
							<input type="password" name="pwtxt" class="lock" placeholder="password">
							<input type="submit" name="btnok" value="Sign In">
							<div class="forgot-grid">
								<label class="checkbox"><input type="checkbox" name="checkbox" checked=""><i></i>Remember me</label>
								<div class="clearfix"> </div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
</html>