<?php 
    include "Header.php";
?>
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
				<div class="row-one">
					<div class="col-md-4 widget">
						<div class="stats-left ">
							<h5>Today</h5>
							<h4>Sales</h4>
						</div>
						<div class="stats-right">
							<label> 551</label>
						</div>
						<div class="clearfix"> </div>	
					</div>
					<div class="col-md-4 widget states-mdl">
						<div class="stats-left">
							<h5>Today</h5>
							<h4>Visitors</h4>
						</div>
						<div class="stats-right">
							<label> 874</label>
						</div>
						<div class="clearfix"> </div>	
					</div>
					<div class="col-md-4 widget states-last">
						<div class="stats-left">
							<h5>Today</h5>
							<h4>Orders</h4>
						</div>
						<div class="stats-right">
							<label>107</label>
						</div>
						<div class="clearfix"> </div>	
					</div>
					<div class="clearfix"> </div>	
				</div>
			
				
				
				<div class="row calender widget-shadow">
					<div class="bs-example widget-shadow" data-example-id="bordered-table"> 
						<h4>Manag Order Table</h4>
						<table class="table table-bordered">
						<thead>
            			 <tr> 
						  <th>#</th> 
						  <th>First Name</th> 
						  <th>Last Name</th> 
						  <th>Username</th> 
						 </tr> 
						</thead> 
						<tbody>
						<tr> 
						 <th scope="row">1</th> 
							<td>Mark</td>
							<td>Otto</td> 
							<td>@mdo</td>
						</tr>
						 <tr> 
							<th scope="row">2</th>
							<td>Jacob</td> 
							<td>Thornton</td> 
							<td>@fat</td>
						</tr> 
						<tr>
						 <th scope="row">3</th> 
						  <td>Larry</td> 
						  <td>the Bird</td>
						  <td>@twitter</td>
						</tr> 
					    </tbody>						 
						</table>
					</div>
					<div class="cal1">
						
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
    <?php
		 include "Footer.php";
	?>  		 