<?php 
    include "Header.php";
?>
		<!-- main content start-->
		<div id="page-wrapper">
		<div class="main-page">
		<div class="row calender widget-shadow">
		<div class="bs-example widget-shadow" data-example-id="contextual-table"> 
						<br/><h3 style="margin-left:10px"> Cart Listing </h3>
						<br/><table class="table">
						<thead> 
						 <tr> 
							<th>Cart-id</th>
							<th>User</th> 
							<th>Quantity</th>
							<th>Action</th>
						 </tr> 
						</thead> 
						<tbody>
						  
						<?php
						 $q="select * from cart_info";
						 $c=mysqli_query($con,$q);
						 
						 while($a=mysqli_fetch_array($c))
						 {
						?>
						 <tr class="active"> 
						   <td><?php echo $a['c_id'];?></td>
					   <td>
						   <?php 
						       $cid=$a['u_id'];
							   $qq="select * from register_tbl where u_id='$cid'";
							   $cc=mysqli_query($con,$qq);
							   while($rr=mysqli_fetch_array($cc))
							   {
								echo $rr['name'];   
							   }
							?>   
						</td>
						<td><?php echo $a['quantity'];?></td>
						<td>	
						  <a onclick="return confirm('Are you sure you want to delect this record')" href="deletecartinfo.php?cid=<?php echo $a['c_id'];?>">
								<i class="fa fa-trash-o" style="transform: scale(1.50,1.50); color:red"></i>
						    </a>	
					     </td>	
						<td>
						<!--   <?php
							   $cid=$a['u_id'];
							   $qq="select * from product_info where p_id='$cid'";
							   $cc=mysqli_query($con,$qq);
							   while($rr=mysqli_fetch_array($cc))
							   {
								echo $rr['title'];   
							   }
							?>
						</td>-->
											   
											   
						 </tr> 
						<?php	
						 }
						?>
						 </tbody> 
						</table> 
					</div>
					</div>
					</div>
					</div>
    <?php
		 include "Footer.php";
	?>  		 