<?php 
include "Header.php";
if(isset($_POST['btnok']))
{
  $oi=$_POST['oidtxt'];
  $oii=$_POST['oitxt'];
  $p=$_POST['pidtxt'];
  $qu=$_POST['qtxt']; 
  $pr=$_POST['ptxt']; 
  $tpr=$_POST['tptxt']; 
  $q="INSERT INTO order_item_detail values('$oi','$oii','$p','$qu','$pr','$tpr')";
  $c=mysqli_query($con,$q);
  
  if($c)
  { 
	?>
	<script>
	alert("Sucessfully insert");
	window.location="viewOrder_detail.php";
	</script>
	<?php

  }	  
  else
  {
	?>
	<script>
	alert("Somthing Goes wrong... Please try again");
	</script>
	<?php
  }
}
?>
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
				<div class="row-one">
				</div>
				<div class="row calender widget-shadow">
						<h3>Add New Order detail</h3>
				<form action="#" method="post" enctype="multipart/form-data">
				<div class="form-body">
				 <form class="form-horizontal"> 
				  <div class="form-group"> 
				   <label for="inputEmail3" class="col-sm-2 control-label">o_id</label>
					<div class="col-sm-9"> 
					 <input type="text" Name="oidtxt" class="form-control" id="inputEmail3" placeholder="Enter Name"> 
					</div> 
				   </div> <br></br>
				    <div class="form-group"> 
				   <label for="inputEmail3" class="col-sm-2 control-label">o_item_id</label>
					<div class="col-sm-9"> 
					 <input type="text" Name="oitxt" class="form-control" id="inputEmail3" placeholder="Enter Name"> 
					</div> 
				   </div> <br></br>
				    <div class="form-group"> 
				   <label for="inputEmail3" class="col-sm-2 control-label">p_id</label>
					<div class="col-sm-9"> 
					 <input type="text" Name="pidtxt" class="form-control" id="inputEmail3" placeholder="Enter Name"> 
					</div> 
				   </div> <br></br>
				    <div class="form-group"> 
				   <label for="inputEmail3" class="col-sm-2 control-label">quantity</label>
					<div class="col-sm-9"> 
					 <input type="text" Name="qtxt" class="form-control" id="inputEmail3" placeholder="Enter Name"> 
					</div> 
				   </div> <br></br>
				   <div class="form-group"> 
				   <label for="inputEmail3" class="col-sm-2 control-label">price</label>
					<div class="col-sm-9"> 
					 <input type="text" Name="ptxt" class="form-control" id="inputEmail3" placeholder="Enter Name"> 
					</div> 
				   </div> <br></br>
				   <div class="form-group"> 
				   <label for="inputEmail3" class="col-sm-2 control-label">total_price</label>
					<div class="col-sm-9"> 
					 <input type="text" Name="tptxt" class="form-control" id="inputEmail3" placeholder="Enter Name"> 
					</div> 
				   </div> <br></br>
					 <div class="col-sm-9"> <br>
						 <div class="col-sm-offset-2">
							<button type="submit" name="btnok" class="btn btn-default">Insert</button> 
							<button type="reset" name="btncl" class="btn btn-default">cancel</button> 
							
							</div>
						</div> 
						 
						</form> 
					</div>
					</form>		
					</div>					
					<div class="cal1"> </div>
				</div>
				<div class="clearfix"> </div>
		</div>
    <?php
		 include "Footer.php";
	?>  		 