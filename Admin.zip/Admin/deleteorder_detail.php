<?php
	include "Header.php";
	$id=$_REQUEST['o_id'];
	$q="delete from order_item_detail where o_id='$id'"; 
	$c=mysqli_query($con,$q);
	if($c)
	{
		?>
		<script>
			alert('Record Deleted Successfully...');
			window.location="viewOrder_detail.php";
		</script>
		<?php
	}
	else
	{
		?>
		<script>
			alert('Errorrr...please try again...');
		</script>
		<?php
	}
?>
<?php
 include "Footer.php";
?>