<?php
	include"header1.php";
?>
 <ol class="breadcrumb">
	<li class="breadcrumb-item">
		<a href="index.php">Home</a>
	</li>
	<li class="breadcrumb-item active">Cart</li>
    </ol>


<?php 	
	include"footer.php";
 ?>