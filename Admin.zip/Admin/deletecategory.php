<?php
	include "Header.php";
	$id=$_REQUEST['id'];
	$q="delete from category where id='$id'"; 
	$c=mysqli_query($con,$q);
	if($c)
	{
		?>
		<script>
			alert('Record Deleted Successfully...');
			window.location="viewcategory.php";
		</script>
		<?php
	}
	else
	{
		?>
		<script>
			alert('Errorrr...please try again...');
		</script>
		<?php
	}
?>
<?php
 include "Footer.php";
?>