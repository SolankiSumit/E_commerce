<?php
	include "Header.php";
	$id=$_REQUEST['oid'];
	$q="delete from order_master where o_id='$id'"; 
	$c=mysqli_query($con,$q);
	if($c)
	{
		?>
		<script>
			alert('Record Deleted Successfully...');
			window.location="viewOrder_master.php";
		</script>
		<?php
	}
	else
	{
		?>
		<script>
			alert('Errorrr...please try again...');
		</script>
		<?php
	}
?>
<?php
 include "Footer.php";
?>  		 