<?php
	include "Header.php";
	$pid=$_REQUEST['pid'];
	$q="delete from product_info where p_id='$pid'"; 
	$c=mysqli_query($con,$q);
	if($c)
	{
		?>
		<script>
			alert('Record Deleted Successfully...');
			window.location="viewproduct_info.php";
		</script>
		<?php
	}
	else
	{
		?>
		<script>
			alert('Errorrr...please try again...');
		</script>
		<?php
	}
?>