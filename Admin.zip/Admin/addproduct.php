<?php 
include "Header.php";
if(isset($_POST['btnok']))
{
	$sl=$_POST['sllanguage'];
  $tt=$_POST['ttxt'];
  $des=$_POST['dtxt'];
  $col=$_POST['cotxt'];
  $siz=$_POST['stxt'];
  $pri=$_POST['ptxt'];
  $im=$_FILES['flimg']['name'];
  $com=$_POST['cmptxt'];
  
  $q="INSERT INTO product_info values ('','$sl','$tt','$des','$col','$siz','$pri','$im','$com')";
  $c=mysqli_query($con,$q);
  
  if($c)
  { 
    move_uploaded_file($_FILES['flimg']['tmp_name'],"upload/".$im);
	?>
	<script>
	alert("Sucessfully insert");
	window.location="viewproduct_info.php";
	</script>
	<?php

  }	  
  else
  {
	?>
	<script>
	alert("Somthing Goes wrong... Please try again");
	</script>
	<?php
  }
}
?>
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
				<div class="row-one">
				</div>
				<div class="row calender widget-shadow">
						<h3>Add New product</h3>
				<form action="#" method="post" enctype="multipart/form-data">
				<div class="form-body">
				 <form class="form-horizontal">
				<div class="form-group">
						<b>Select Category</b>
						<br/>
						<select name ="sllanguage">
							<option>Select Category</option>
							<?php
						 $q="select * from category";
						 $c=mysqli_query($con,$q);
						 
						 while($a=mysqli_fetch_array($c))
						 {
						?>
									<option value="<?php echo $r['id'];?>">
										<?php echo $a['name'];?>
									</option>
							<?php
								}
							?>
						</select>	
					</div>				 
				  <div class="form-group"> 
				   <label for="inputEmail3" class="col-sm-2 control-label">Title</label>
					<div class="col-sm-9"> 
					 <input type="text" Name="ttxt" class="form-control" id="inputEmail3" placeholder="Enter Title"> 
					</div> 
				   </div> <br></br>
				    <div class="form-group"> 
				   <label for="inputEmail3" class="col-sm-2 control-label">Description</label>
					<div class="col-sm-9"> 
					 <input type="text" Name="dtxt" class="form-control" id="inputEmail3" placeholder="Enter Description"> 
					</div> 
				   </div> <br></br>
				    <div class="form-group"> 
				   <label for="inputEmail3" class="col-sm-2 control-label">color</label>
					<div class="col-sm-9"> 
					 <input type="text" Name="cotxt" class="form-control" id="inputEmail3" placeholder="Enter Color"> 
					</div> 
				   </div> <br></br>
				    <div class="form-group"> 
				   <label for="inputEmail3" class="col-sm-2 control-label">size</label>
					<div class="col-sm-9"> 
					 <input type="text" Name="stxt" class="form-control" id="inputEmail3" placeholder="Enter size"> 
					</div> 
				   </div> <br></br>
				    <div class="form-group"> 
				   <label for="inputEmail3" class="col-sm-2 control-label">price</label>
					<div class="col-sm-9"> 
					 <input type="text" Name="ptxt" class="form-control" id="inputEmail3" placeholder="Enter Price"> 
					</div> 
				   </div> <br></br>
				    <div class="form-group"> 
				   <label for="inputEmail3" class="col-sm-2 control-label">company</label>
					<div class="col-sm-9"> 
					 <input type="text" Name="cmptxt" class="form-control" id="inputEmail3" placeholder="Enter company"> 
					</div> 
				   </div> <br></br>
				   <div class="form-group"> 
					 <label for="inputEmail3" class="col-sm-2 control-label">product Image</label> 
					<div class="col-sm-9"> 
						<input type="file"  Name="flimg" id="inputEmail3"> 
					 </div>
					 </div>
					 <div class="col-sm-9"> <br>
						 <div class="col-sm-offset-2">
							<button type="submit" name="btnok" class="btn btn-default">Insert</button> 
							<button type="reset" name="btncl" class="btn btn-default">cancel</button> 
							
							</div>
						</div> 
						 
						</form> 
					</div>
					</form>		
					</div>					
					<div class="cal1"> </div>
				</div>
				<div class="clearfix"> </div>
		</div>
    <?php
		 include "Footer.php";
	?>  		 