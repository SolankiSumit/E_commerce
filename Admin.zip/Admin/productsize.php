<?php
    include "Header.php";
	$pid=$_REQUEST['pid'];
	if(isset($_POST['btnok']))
{
  $size=$_POST['sztxt'];
  	
  $q="INSERT INTO product_size values ('','$pid','$size','1')";
  $c=mysqli_query($con,$q);
  
  if($c)
  { 
  ?>
	<script>
	alert("Sucessfully insert");
	window.location="productsize.php?pid=<?php echo $pid;?>";
	</script>
	<?php

  }	  
  else
  {
	?>
	<script>
	alert("Somthing Goes wrong... Please try again");
	</script>
	<?php
  }  
}
?>

		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
			 <div class="row calender widget-shadow">
				<div class="bs-example widget-shadow" data-example-id="contextual-table"> 
						<h3>Size listing</h3>
						<form action="#" method="post">
						<table width=100%>
							<tr>
								<td>
									<input style="margin:10px 10px 10px 10px" type="text" name="sztxt" class="form-control" id="inputEmail3" placeholder="Enter size"/>
								</td>
								<td width=20px></td>
								<td>
									<button type="submit" name="btnok" class="btn btn-default" > Add Size</button> 
								</td>
							</tr>
						</table>
						</form>
						
						<table class="table">
						<thead> 
						 <tr> 
							<th>ID</th> 
							<th>Size</th>
							<th>Available</th>
							 
					     </tr> 
						</thead> 
						<tbody>
						<?php
						 $q="select * from product_size where p_id='$pid'";
						 $c=mysqli_query($con,$q);
						 
						 while($a=mysqli_fetch_array($c))
						 {
						?>
						 <tr class="active"> 
						  
						   <td><?php echo $a['size_id'];?></td>
						   <td><?php echo $a['size'];?></td> 
						   <td>
						   <?php if($a['available']==1) 
								 {
										echo "Yes" ;
								 }
								 else
								 {
									 echo "No";
								 }
								 ?>
						   </td>
						   <td>
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						      <a onclick="return confirm('Are you sure you want to delect this record')" href="deletesize.php?id=<?php echo $a['size_id'];?>">
								<!--<i class="fa fa-trash-o" style="transform: scale(1.25,1.25); color:red"></i>-->
						    </a>	
					     </td>	 
                          </tr>
						<?php	
						 }
						?>
						 
						  
						  </tbody> 
						</table> 
					</div>
					<div class="cal1">
						
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
    <?php
		 include "Footer.php";
	?>  		 