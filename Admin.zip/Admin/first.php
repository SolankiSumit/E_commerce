<h2>Fill Your Information</h2>
<form method="post" action="process.php">

<b>Enter Name</b>
	<input type="text" name="nmtxt"/>
<br/><br/>
<b>Enter Username</b>
	<input type="text" name="untxt"/>
<br/><br/>
<b>Enter Mobile NO</b>
	<input type="text" name="mbtxt"/>
<br/><br/>
<b>Enter Password</b>
    <input type="password" name="pwtxt"/>
<br><br/>
		<input type="submit" name="btnok" value="Login"/>
		<input type="reset" value="cancel"/>
</form>
