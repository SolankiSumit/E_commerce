<?php 
    include "Header.php";
?>
		<!-- main content start-->
		   <div id="page-wrapper">
			<div class="main-page">
			 <div class="row calender widget-shadow">
			  <div class="bs-example widget-shadow" data-example-id="contextual-table"> 
						<br/><h3 style="margin-left:10px">Product listing</h3>
						<h3></h3>
						<table class="table">
						<a href="addproduct.php" style="float:right">Add New product</a>
						<thead> 
						 <tr> 
							<th>p_id</th>
							<th>C_ID</th> 
							<th>title</th>
							<th>Description</th>
							<th>color</th> 
							<th>size</th> 
							<th>price</th> 
							<th>company</th>
							<th>image</th>
							<th>Action</th>
					     </tr> 
						</thead> 
						<tbody>
						  
						<?php
						 $q="select * from product_info";
						 $c=mysqli_query($con,$q);
						 
						 while($a=mysqli_fetch_array($c))
						 {
							
						?>
						 <tr class="active"> 
						   <td><?php echo $a['p_id'];?></td>
						   <td>
						   <?php 
						       $cid=$a['c_id'];
							   $qq="select * from category where id='$cid'";
							   $cc=mysqli_query($con,$qq);
							   while($rr=mysqli_fetch_array($cc))
							   {
								echo $rr['name'];   
							   }
							?>   
							</td>
						   <td><?php echo $a['title'];?></td>
						   <td><?php echo $a['Description'];?></td>
						   <td><?php echo $a['color'];?></td>
						   <td><a href="productsize.php?pid=<?php echo $a['p_id'];?>">
								<i class="fa fa-eye"></i>
						   </a></td>
						   <td><?php echo $a['price'];?></td>						   
						   <td><?php echo $a['company'];?></td>						   
						   
						 <td>
						   <img src="upload/<?php echo $a['image']; ?>"
						   height=80 width=80/>
						   </td>
						   
                          <td>
						   <a href="editproduct.php?pid=<?php echo $a['p_id'];?>">
								<i class="fa fa-edit" style="transform: scale(1.50,1.50); color:green"></i>
						    </a>	
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						      <a onclick="return confirm('Are you sure you want to delect this record')" href="deleteproduct.php?pid=<?php echo $a['p_id'];?>">
								<i class="fa fa-trash-o" style="transform: scale(1.50,1.50); color:red"></i>
						    </a>	
					     </td>						   
						 </tr>
						<?php	
						 }
						?>
						 
						 </tbody> 
						</table> 
					</div>
					<div class="cal1"> </div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
<?php
    include "Footer.php";
?>  		 