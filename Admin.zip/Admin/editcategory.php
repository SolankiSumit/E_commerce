<?php 
include "Header.php";
$id=$_REQUEST['id'];
$q="Select * from category where id='$id'";
$c=mysqli_query($con,$q);
while($r=mysqli_fetch_array($c))
{
	$cname=$r['name'];
	$cimg=$r['image'];
}

if(isset($_POST['btnok']))
{
	if($_FILES['flimg']['name']!="")
	{
		$im=$_FILES['flimg']['name'];
	}	 
	else
	{
		$im=$cimg;
	}
  
  $nm=$_POST['nmtxt'];
  	
  $q="update category set name='$nm',image='$im' where id='$id'";
  $c=mysqli_query($con,$q);
  
  if($c)
  { 
    move_uploaded_file($_FILES['flimg']['tmp_name'],"upload/".$im);
	?>
	<script>
	alert("Sucessfully insert");
	window.location="viewcategory.php";
	</script>
	<?php

  }	  
  else
  {
	?>
	<script>
	alert("Somthing Goes wrong... Please try again");
	</script>
	<?php
  }
  
  
}
?>
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
				<div class="row-one">
				</div>
				<div class="row calender widget-shadow">
						<h3>Edit Category</h3>
				<form action="#" method="post" enctype="multipart/form-data">
				<div class="form-body">
				 <form class="form-horizontal"> 
				  <div class="form-group"> 
				   <label for="inputEmail3" class="col-sm-2 control-label">Category Name</label>
					<div class="col-sm-9"> 
					 <input type="text" Name="nmtxt" value=<?php echo $cname;?> class="form-control" id="inputEmail3" placeholder="Enter Name"> 
					</div> 
				   </div> <br></br>

					<div class="form-group"> 
					 <label for="inputEmail3" class="col-sm-2 control-label">Category Image</label> 
					<div class="col-sm-9"> 
					<img src="upload/<?php echo $cimg ;?>" height=50 width=50/>
						<input type="file"  Name="flimg" id="inputEmail3"> 
					 </div>
					 </div>
					 <div class="col-sm-9"> <br>
						 <div class="col-sm-offset-2">
							<button type="submit" name="btnok" class="btn btn-default">update</button> 
							<button type="reset" name="btncl" class="btn btn-default">cancel</button> 
							
							</div>
						</div> 
						 
						</form> 
					</div>
					</form>		
					</div>					
					<div class="cal1"> </div>
				</div>
				<div class="clearfix"> </div>
		</div>
    <?php
		 include "Footer.php";
	?>  		 