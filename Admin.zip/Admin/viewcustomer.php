<?php 
    include "Header.php";
?>
		<!-- main content start-->
             <div id="page-wrapper">
			   <div class="main-page">
		        <div class="row calender widget-shadow">
		         <div class="bs-example widget-shadow" data-example-id="contextual-table"> 
						<br/><h3 style="margin-left:10px">Customer Info </h3>
						<table class="table">
						<thead> 
						 <tr> 
							<th>c_id</th>
							<th>name</th> 
							<th>email</th>
							<th>password</th>
							<th>m_no</th>
							<th>city</th>
							<th>address</th>
							<th>action</th>
				         </tr> 
						</thead> 
						<tbody>
						  
						<?php
						 $q="select * from customer_info";
						 $c=mysqli_query($con,$q);
						 while($a=mysqli_fetch_array($c))
						 {
						?>
						 <tr class="active"> 
						   <td><?php echo $a['c_id'];?></td>
                           <td><?php echo $a['name'];?></td>						  
						   <td><?php echo $a['email'];?></td>
						   <td><?php echo $a['password'];?></td>
						   <td><?php echo $a['m_no'];?></td>						   
						   <td><?php echo $a['city'];?></td>						   
						   <td><?php echo $a['address'];?></td>	
						<td>	
						  <a onclick="return confirm('Are you sure you want to delect this record')" href="deletecustomer.php?cid=<?php echo $a['c_id'];?>">
								<i class="fa fa-trash-o" style="transform: scale(1.50,1.50); color:red"></i>
						    </a>	
					     </td>						   
						 </tr> 
						<?php	
						 }
						?>
						 </tbody> 
						</table> 
					  </div>
					 </div>
					</div>
				  <div class="cal1"></div>
				 </div>
				<div class="clearfix"> </div>
    <?php
		 include "Footer.php";
	?>  		 