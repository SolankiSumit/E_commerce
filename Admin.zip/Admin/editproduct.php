<?php 
include "Header.php";
$pid=$_REQUEST['pid'];
$q="select * from product_info where p_id='$pid'";
$c=mysqli_query($con,$q);
while($r=mysqli_fetch_array($c))
{
	$psl=$_POST['c_id'];
	$ptitle=$r['title'];
	$pdes=$r['Description'];
	$pcol=$r['color'];
	$psiz=$r['size'];
	$ppri=$r['price'];
	$pim=$r['image'];
	$pcom=$r['company'];
}


if(isset($_POST['btnok']))
{
	if($_FILES['flimg']['name']!="")
	{
		$im=$_FILES['flimg']['name'];
	}	 
	else
	{
		$im=$pim;
	}		
  $sl=$_POST['sllanguage'];
  $tt=$_POST['ttxt'];
  $des=$_POST['dtxt'];
  $col=$_POST['cotxt'];
  $siz=$_POST['stxt'];
  $pri=$_POST['ptxt'];
  $com=$_POST['cmptxt'];
  
  $q="update product_info set c_id='$sl',title='$tt',Description='$des',color='$col',size='$siz',price='$pri',image='$im',company='$com' where p_id='$pid'";
  $c=mysqli_query($con,$q);
  
  if($c)
  { 
    move_uploaded_file($_FILES['flimg']['tmp_name'],"upload/".$im);
	?>
	<script>
	alert("Sucessfully insert");
	window.location="viewproduct_info.php";
	</script>
	<?php

  }	  
  else
  {
	?>
	<script>
	alert("Somthing Goes wrong... Please try again");
	</script>
	<?php
  }
}
?>
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
				<div class="row-one">
				</div>
				<div class="row calender widget-shadow">
						<h3>Edit product</h3>
				<form action="#" method="post" enctype="multipart/form-data">
				<div class="form-body">
				 <form class="form-horizontal">
					<div class="form-group">
						<b>Select Category</b>
						<br/>
						<select name ="sllanguage">
							<option>Select Category</option>
							<?php
						 $q="select * from category";
						 $c=mysqli_query($con,$q);
						 
						 while($a=mysqli_fetch_array($c))
						 {
						?>
									<option value="<?php echo $a['id'];?>" selected>
										<?php echo $a['name'];?>
									</option>
							<?php
								}
							?>
						</select>	
					</div>		
				  <div class="form-group"> 
				   <label for="inputEmail3" class="col-sm-2 control-label">Title</label>
					<div class="col-sm-9"> 
					 <input type="text" Name="ttxt" value="<?php echo $ptitle;?>" class="form-control" id="inputEmail3" placeholder="Enter Name"> 
					</div> 
				   </div> <br></br>
				    <div class="form-group"> 
				   <label for="inputEmail3" class="col-sm-2 control-label">Description</label>
					<div class="col-sm-9"> 
					 <input type="text" Name="dtxt" value="<?php echo$pdes;?>"class="form-control" id="inputEmail3" placeholder="Enter Name"> 
					</div> 
				   </div> <br></br>
				    <div class="form-group"> 
				   <label for="inputEmail3" class="col-sm-2 control-label">color</label>
					<div class="col-sm-9"> 
					 <input type="text" Name="cotxt"value="<?php echo$pcol;?>" class="form-control" id="inputEmail3" placeholder="Enter Name"> 
					</div> 
				   </div> <br></br>
				    <div class="form-group"> 
				   <label for="inputEmail3" class="col-sm-2 control-label">size</label>
					<div class="col-sm-9"> 
					 <input type="text" Name="stxt" value="<?php echo$psiz;?>"class="form-control" id="inputEmail3" placeholder="Enter Name"> 
					</div> 
				   </div> <br></br>
				    <div class="form-group"> 
				   <label for="inputEmail3" class="col-sm-2 control-label">price</label>
					<div class="col-sm-9"> 
					 <input type="text" Name="ptxt" value="<?php echo $ppri;?>"class="form-control" id="inputEmail3" placeholder="Enter Name"> 
					</div> 
				   </div> <br></br>
				    <div class="form-group"> 
				   <label for="inputEmail3" class="col-sm-2 control-label">company</label>
					<div class="col-sm-9"> 
					 <input type="text" Name="cmptxt" value="<?php echo $pcom;?>"class="form-control" id="inputEmail3" placeholder="Enter Name"> 
					</div> 
				   </div> <br></br>
				   <div class="form-group"> 
					 <label for="inputEmail3" class="col-sm-2 control-label">product Image</label> 
					<div class="col-sm-9"> 
					<img src="upload/<?php echo $pim;?>" height=50 width=50/>
						<input type="file"  Name="flimg" id="inputEmail3"> 
					 </div>
					 </div>
					 <div class="col-sm-9"> <br>
						 <div class="col-sm-offset-2">
							<button type="submit" name="btnok" class="btn btn-default">Insert</button> 
							<button type="reset" name="btncl" class="btn btn-default">cancel</button> 
							
							</div>
						</div> 
						 
						</form> 
					</div>
					</form>		
					</div>					
					<div class="cal1"> </div>
				</div>
				<div class="clearfix"> </div>
		</div>
    <?php
		 include "Footer.php";
	?>  		