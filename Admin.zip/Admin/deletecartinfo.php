<?php
	include "Header.php";
	$id=$_REQUEST['cid'];
	$q="delete from cart_info where c_id='$id'"; 
	$c=mysqli_query($con,$q);
	if($c)
	{
		?>
		<script>
			alert('Record Deleted Successfully...');
			window.location="viewcartinfo.php";
		</script>
		<?php
	}
	else
	{
		?>
		<script>
			alert('Errorrr...please try again...');
		</script>
		<?php
	}
?>
<?php
 include "Footer.php";
?>  		 