<?php 
    include "Header.php";
?>
		<!-- main content start-->
			<div id="page-wrapper">
			<div class="main-page">
			 <div class="row calender widget-shadow">
				<div class="bs-example widget-shadow" data-example-id="contextual-table"> 
					<br/><h3 style="margin-left:10px">FeedBack</h3>
						
						<table class="table">
						<thead> 
						 <tr> 
							<th>fid</th>
							<th>User Name</th>
							<th>Email</th>
						    <th>Phone no.</th>
							<th>subject</th>
							<th>f-date</th> 
							<th>Action</th>
						 </tr> 
						</thead> 
						<tbody>
						  
						<?php
						 $q="select * from feedback";
						 $c=mysqli_query($con,$q);
						 
						 while($a=mysqli_fetch_array($c))
						 {
							
						?>
						 <tr class="active"> 
						   <td><?php echo $a['f_id'];?></td>
						   <td><?php echo $a['name'];?></td>
						   <td><?php echo $a['email'];?></td>
						   <td><?php echo $a['phone no'];?></td>
						   <td><?php echo $a['subject'];?></td>
							<td><?php echo $a['f_date'];?></td>					   
						   
                          <td>	
						  <a onclick="return confirm('Are you sure you want to delect this record')" href="deletefeedback.php?fid=<?php echo $a['f_id'];?>">
								<i class="fa fa-trash-o" style="transform: scale(1.50,1.50); color:red"></i>
						    </a>	
					     </td>						   
						 </tr> 
						<?php	
						 }
						?>
						 
						 </tbody> 
						</table> 
					</div>
					<div class="cal1">
						
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
    <?php
		 include "Footer.php";
	?>  		 