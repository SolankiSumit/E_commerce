	<?php
    include "Header.php";
?>
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
			 <div class="row calender widget-shadow">
				<div class="bs-example widget-shadow" data-example-id="contextual-table"> 
						<br/><h3 style="margin-left:10px">Category Listing</h3>
						<h3></h3>
						<table class="table">
						<a href="addnewcategory.php" style="float:right">Add New Category</a>
						<thead> 
						 <tr> 
							<th>ID</th> 
							<th>Category-Name</th>
							<th>Category-Image</th>
							<th>Action</th> 
					     </tr> 
						</thead> 
						<tbody>
						<?php
						 $q="select * from category";
						 $c=mysqli_query($con,$q);
						 
						 while($a=mysqli_fetch_array($c))
						 {
						?>
						 <tr class="active"> 
						  
						   <td><?php echo $a['id'];?></td>
						   <td><?php echo $a['name'];?></td> 
						   <td>
						   <img src="upload/<?php echo $a['image']; ?>"
						   height=80 width=80/>
						   </td>
						   <td>
						   <a href="editcategory.php?id=<?php echo $a['id'];?>">
								<i class="fa fa-edit" style="transform: scale(1.25,1.25); color:green"></i>
						    </a>	
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						      <a onclick="return confirm('Are you sure you want to delect this record')" href="deletecategory.php?id=<?php echo $a['id'];?>">
								<i class="fa fa-trash-o" style="transform: scale(1.25,1.25); color:red"></i>
						    </a>	
					     </td>	 
                          </tr>
						<?php	
						 }
						?>
						 
						  
						  </tbody> 
						</table> 
					</div>
					<div class="cal1">
						
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
    <?php
		 include "Footer.php";
	?>  		 