<?php 
    include "Header.php";
?>
		<!-- main content start-->
			<div id="page-wrapper">
			<div class="main-page">
			 <div class="row calender widget-shadow">
				<div class="bs-example widget-shadow" data-example-id="contextual-table"> 
						<br/><h3 style="margin-left:10px">Order mastre </h3>
						<h3></h3>
						<table class="table">
						<thead> 
						 <tr> 
							<th>o_id</th>
							<th>u_ID</th> 
							<th>total_quantity</th>
							<th>total_price</th>
							<th>adderess</th> 
							<th>o_date</th> 
							<th>Action</th>
						 </tr> 
						</thead> 
						<tbody>
						  
						<?php
						 $q="select * from order_master";
						 $c=mysqli_query($con,$q);
						 
						 while($a=mysqli_fetch_array($c))
						 {
							
						?>
						 <tr class="active"> 
						   <td><?php echo $a['o_id'];?></td>
					   <td>
						   <?php 
						       $cid=$a['u_id'];
							   $qq="select * from register_tbl where u_id='$cid'";
							   $cc=mysqli_query($con,$qq);
							   while($rr=mysqli_fetch_array($cc))
							   {
								echo $rr['name'];   
							   }
							?>   
							</td>
						   <td><?php echo $a['total_qty'];?></td>
						   <td><?php echo $a['total_price'];?></td>
						   <td><?php echo $a['adderess'];?></td>
						   <td><?php echo $a['o_date'];?></td>					   
						   
                          <td>	
						  <a onclick="return confirm('Are you sure you want to delect this record')" href="deleteorder_master.php?oid=<?php echo $a['o_id'];?>">
							<i class="fa fa-trash-o" style="transform: scale(1.50,1.50); color:red"></i>
			                   &nbsp;&nbsp;
						    <a href="viewOrder_detail.php?pid=<?php echo $a['o_id'];?>">
								<i class="fa fa-eye"></i>
						   </a>
						  </a>	
					     </td>						   
						 </tr> 
						<?php	
						 }
						?>
						 
						 </tbody> 
						</table> 
					</div>
					<div class="cal1">
						
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
    <?php
		 include "Footer.php";
	?>  		 