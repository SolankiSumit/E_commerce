<?php 
include "Header.php";
if(isset($_POST['btnok']))
{
  $nm=$_POST['nmtxt'];
  $im=$_FILES['flimg']['name'];
		
  $q="INSERT INTO category values ('','$nm','$im')";
  $c=mysqli_query($con,$q);
  
  if($c)
  { 
    move_uploaded_file($_FILES['flimg']['tmp_name'],"upload/".$im);
	?>
	<script>
	alert("Sucessfully insert");
	window.location="viewcategory.php";
	</script>
	<?php

  }	  
  else
  {
	?>
	<script>
	alert("Somthing Goes wrong... Please try again");
	</script>
	<?php
  }  
}
?>
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
				<div class="row-one">
				</div>
				<div class="row calender widget-shadow">
						<h3>Add New Category</h3>
				<form action="#" method="post" enctype="multipart/form-data">
				<div class="form-body">
				 <form class="form-horizontal"> 
				  <div class="form-group"> 
				   <label for="inputEmail3" class="col-sm-2 control-label">Category Name</label>
					<div class="col-sm-9"> 
					 <input type="text" Name="nmtxt" class="form-control" id="inputEmail3" placeholder="Enter Name"> 
					</div> 
				   </div> <br></br>

					<div class="form-group"> 
					 <label for="inputEmail3" class="col-sm-2 control-label">Category Image</label> 
					<div class="col-sm-9"> 
						<input type="file"  Name="flimg" id="inputEmail3"> 
					 </div>
					 </div>
					 <div class="col-sm-9"> <br>
						 <div class="col-sm-offset-2">
							<button type="submit" name="btnok" class="btn btn-default">Insert</button> 
							</div>
						</div> 
						 
						</form> 
					</div>
					</form>		
					</div>					
					<div class="cal1"> </div>
				</div>
				<div class="clearfix"> </div>
		</div>
    <?php
		 include "Footer.php";
	?>  		 