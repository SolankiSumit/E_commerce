<?php 
    include "Header.php";
?>
		<!-- main content start-->
			<div id="page-wrapper">
			<div class="main-page">
			 <div class="row calender widget-shadow">
				<div class="bs-example widget-shadow" data-example-id="contextual-table"> 
						<br/><h3 style="margin-left:10px">Order Detail</h3>
				     	<h3></h3>
						<table class="table">
						<thead> 
						 <tr> 
							<th>o_id</th> 
							<th>o_item_id</th>
							<th>Product Name</th>
							<th>size</th>
							<th>quantity</th> 
							<th>price</th> 
							<th>total_price</th>
							<th>Action</th>
							
					     </tr> 
						</thead> 
						<tbody>
						<?php
						 $q="select * from order_item_detail ";
						 $c=mysqli_query($con,$q);
						 
						 while($a=mysqli_fetch_array($c))
						 {
						?>
						 <tr class="active"> 
						  
						   <td><?php echo $a['order_item_id'];?></td>
						   <td><?php echo $a['order_id'];?></td> 
						   <td><?php echo $a['p_id'];?></td> 
						   <td><?php echo $a['size'];?></td> 
						   <td><?php echo $a['quantity'];?></td> 
						   <td><?php echo $a['price'];?></td> 
						   <td><?php echo $a['total_price'];?></td> 
						  
						   <td>
						      <a onclick="return confirm('Are you sure you want to delect this record')" href="deleteorder_detail.php?o_id=<?php echo $a['order_item_id'];?>">
								<i class="fa fa-trash-o" style="transform: scale(1.25,1.25); color:red"></i>
						    </a>	
					     </td>	 
                          </tr>
						<?php	
						 }
						?>
						 
						  
						  </tbody> 
						</table> 
					</div>
					<div class="cal1">
						
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
    <?php
		 include "Footer.php";
	?>  		 