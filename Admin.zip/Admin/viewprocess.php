<?php
	$name=$_POST["nmtxt"];
	$username=$_POST["untxt"];
	$mobile=$_POST["mbtxt"];
	$password=$_POST["pwtxt"];
 //connect with db
  $con=mysqli_connect("localhost","root","","collegianfootwear_db");
 //built query  
   $q="INSERT INTO register_tbl values('','$name','$username','$mobile','$password')";
 //execute query
	$r=mysqli_query($con,$q);
	
	if($r)
	{
	   echo "Successfully Inserted";
	}
	else
	{
		echo "Somthing goes wrong";
	}
	
	
?>