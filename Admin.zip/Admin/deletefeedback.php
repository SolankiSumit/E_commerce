<?php
	include "Header.php";
	$id=$_REQUEST['fid'];
	$q="delete from feedback where f_id='$id'"; 
	$c=mysqli_query($con,$q);
	if($c)
	{
		?>
		<script>
			alert('Record Deleted Successfully...');
			window.location="viewfeedback.php";
		</script>
		<?php
	}
	else
	{
		?>
		<script>
			alert('Errorrr...please try again...');
		</script>
		<?php
	}
?>
<?php
 include "Footer.php";
?>