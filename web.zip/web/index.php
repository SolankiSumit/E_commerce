<?php
	include "header.php";
?>



    <section class="about py-md-5 py-5">
        <div class="container-fluid">
            <div class="feature-grids row px-3">
                <div class="col-lg-3 gd-bottom">
                    <div class="bottom-gd row">
                        <div class="icon-gd col-md-3 text-center"><span class="fa fa-truck" aria-hidden="true"></span></div>
                        <div class="icon-gd-info col-md-9">
                            <h3 class="mb-2">FREE SHIPPING</h3>
                            <p>On all order over RS.2000</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 gd-bottom">
                    <div class="bottom-gd row bottom-gd2-active">
                        <div class="icon-gd col-md-3 text-center"><span class="fa fa-bullhorn" aria-hidden="true"></span></div>
                        <div class="icon-gd-info col-md-9">
                            <h3 class="mb-2">FREE RETURN</h3>
                            <p>On 1st exchange in 8 days</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 gd-bottom">
                    <div class="bottom-gd row">
                        <div class="icon-gd col-md-3 text-center"> <span class="fa fa-gift" aria-hidden="true"></span></div>

                        <div class="icon-gd-info col-md-9">
                            <h3 class="mb-2">MEMBER DISCOUNT</h3>
                            <p>Register & save up to 20%</p>
                        </div>

                    </div>
                </div>
                <div class="col-lg-3 gd-bottom">
                    <div class="bottom-gd row">
                        <div class="icon-gd col-md-3 text-center"> <span class="fa fa-usd" aria-hidden="true"></span></div>
                        <div class="icon-gd-info col-md-9">
                            <h3 class="mb-2">PREMIUM SUPPORT</h3>
                            <p>Support 24 hours per day</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- //ab -->
    <!--/testimonials-->
    <section class="testimonials py-5">
        <div class="container">
            <div class="test-info text-center">
                <h3 class="my-md-2 my-3">Mahendra Singh Dhoni</h3>

                <ul class="list-unstyled w3layouts-icons clients">
                    <li>
                        <a href="#">
                            <span class="fa fa-star"></span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <span class="fa fa-star"></span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <span class="fa fa-star"></span>
                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <span class="fa fa-star-half-o"></span>
                        </a>
                    </li>
                </ul>
                <p><span class="fa fa-quote-left"></span>  Take the road less travelled, but first get some new shoes. <span class="fa fa-quote-right"></span></p>

            </div>
        </div>
    </section>
    <!--//testimonials-->
    <!--<!--/ab -->
    <!-- brands -->
     <section class="brands py-5" id="brands" style="background-color: black;">
    <div class="container py-lg-0">
        <div class="row text-center brand-items" style="display: flex; justify-content: center;">
            <div class="col-sm-2 col-3">
                <a href="category.php"><img src="images/nikes.png" alt="Shoe Brand 1" style="max-width: 100%; height: auto;"></a>
            </div>
            <div class="col-sm-2 col-3">
                <a href="category.php"><img src="images/addidas.png" alt="Shoe Brand 2" style="max-width: 100%; height: auto;"></a>
            </div>
            <div class="col-sm-2 col-3">
                <a href="category.php"><img src="images/puma.png" alt="Shoe Brand 3" style="max-width: 100%; height: auto;"></a>
            </div>
            <div class="col-sm-2 col-3" style="margin-bottom: 50px;">
                <a href="category.php"><img src="images/rebook.png" alt="Shoe Brand 4" style="max-width: 100%; height: auto;"></a>
            </div>
            <div class="col-sm-2 col-3">
                <a href="category.php"><img src="images/nb.png" alt="Shoe Brand 5" style="max-width: 100%; height: auto;"></a>
            </div>
            <div class="col-sm-2 col-3">
                <a href="category.php"><img src="images/bata.png" alt="Shoe Brand 6" style="max-width: 100%; height: auto;"></a>
            </div>
        </div>
    </div>
</section>

    <!-- brands -->
    <?php
	 include"footer.php";
	?>


</html> 
